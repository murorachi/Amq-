## V82.76 script_004 boundary audit — 2026-10-18
- Engineering-only static analysis checkpoint; no production code moved or changed.
- Added `tools/script004_boundary_audit.cjs`, a 15-assertion contract test, and reports for shared closure state, browser/API calls, `window` exports, listener and timer candidates.
- `script_004.htmlpart` remains 98,849 bytes / SHA-256 `23dacccdc25538416c4ddba91f4e044df7c4491924d1099d8cdf0a60fb4f4bdc`; parser diagnostics: 0.
- Full runner: 18/18 commands passed; 237 unit/contract assertions passed; 29 constrained browser integration assertions passed; integrity verifier: 112/112. Two independent builds match V82.72.
- Product remains `dist/amq_learning_tool_v82_72.html`, 8,787,018 bytes / SHA-256 `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`. Immutable V82.65 remains unchanged.
- GitHub report-only commit: `b885491e182b639a2bf15098eb46ef95bcce2bbe`; remote report blob SHA `7a4de28eb57707c3ce9f34d7f8d1b4798c7bcbf4`, verified by readback. This is not a complete source publication.
- Next: add a production-source characterization contract for `getQuizPool()` before considering extraction. Real-origin acceptance and coherent GitHub source publication remain open.

## V82.75 quiz suggestion renderer extraction — 2026-10-18
- Extracted `renderQuizSuggestionLabelV824()` and `buildSuggestions()` as `src/modules/quiz_suggestion_renderer.js`, and the target/catalog/cache/shared-selection block as `src/modules/quiz_suggestion_controller.js`, both inserted at their exact original positions in `script_004`.
- Renderer module fingerprint: 3338 bytes / `b65d52d0d0b4c384d789c6f16ddbcd42b505a84963ff27af7e278006a9ebfe21`; controller module: 2790 bytes / `70f84947c115d4f787c15b0a867c2f1a79f2a4d017334b4069321dca17744aaf`. `script_004` fragment now 98849 bytes / `23dacccdc25538416c4ddba91f4e044df7c4491924d1099d8cdf0a60fb4f4bdc`; the contract reconstructs its pre-extraction 104,875-byte / `7720cc92107fda836debe1e50a8ac1f8b36de17fb1bb484168d262c55db208b1` bytes exactly.
- Source modules: 6. Checklist: 97 items (41 scripts + 50 styles + 6 modules). Product output remains unchanged at V82.72 fingerprint `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`.
- Full runner: 17/17 commands passed; 222 unit/contract assertions, 29 browser integration assertions and 112 integrity checks passed. Two builds remain byte-identical to V82.72.
- Engineering ZIP: CRC and sidecar verification passed; exact byte count and SHA-256 are recorded in `reports/V82_75_QUIZ_SUGGESTION_RENDERER_EXTRACTION_01_SHA256.txt`.
- GitHub report-only upload: commit `6603220f1bb3592a4419fbe0c8915f1f3c393c6f`; remote report blob SHA `9158a4afbf26847482cffbb9495ee6a42788375f`. Remote readback confirmed the report exists. The branch still returns 404 for `reports/FRAGMENT_MANIFEST.json`, so complete source publication is not achieved.
- No product logic change intended. Real-origin acceptance and coherent GitHub source publication remain open.

## V82.73 localhost-origin acceptance attempt — 2026-10-18
- Added `tests/browser/real_origin_acceptance_localhost.py`, a no-shim Chromium test for native localStorage/IndexedDB persistence and real embedded-database suggestion selection over localhost HTTP.
- Attempted execution against `dist/amq_learning_tool_v82_72.html`; Chromium navigation failed immediately with `net::ERR_BLOCKED_BY_ADMINISTRATOR` at the localhost URL. Only the artifact-exists precondition passed; no origin-dependent behavior assertion ran. This is an environment block, not a product pass/failure.
- The test was not added to the mandatory full runner because this environment consistently blocks localhost navigation. No app storage key or test database was created; no user data was touched.
- No production HTML/source changed. V82.72 remains 8,787,018 bytes / SHA-256 `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`; immutable V82.65 baseline remains unchanged.
- Existing deterministic suite still records 14/14 commands, 29 browser assertions, 173 unit/contract assertions and 106 integrity checks passed from the latest run.
- GitHub remains partial: report publication can be verified, but the complete matching source/build/test tree is not yet remotely reproducible.

# Current status

Current engineering checkpoint: **V82.71 SUGGESTION-EVENT-OWNERSHIP-AUDIT-01** (test/report-only follow-on to the V82.70 product output). Product baseline remains immutable V82.65. Candidate policy and storage repository are source modules; storage repository bytes are injected at the original position. Runtime remains a single standalone classic HTML document, byte-identical to baseline. Unit/build checks and opaque-origin Chromium smoke have been executed. User acceptance: **ACCEPTED** (confirmed 2026-10-18). Engineering/browser coverage remains **PARTIAL** because direct file-origin navigation is blocked and persistence/IndexedDB/audio/network/multiplayer multi-client acceptance cannot be verified in this environment.

## Locked baseline
- HTML: 8,786,930 bytes; SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`.
- V82.65 baseline HTML and package are immutable.

## V82.69 changes
- Extracted `src/modules/storage_repository.htmlpart` from `src/scripts/script_027.htmlpart` without changing its bytes or execution position.
- Build manifest now validates two source modules and their insertion markers.
- Added nine synthetic-storage tests covering user namespaces, validation, snapshots, transactions, rollback, allowlisted legacy import and adapters.
- Added six full-backup manifest/allowlist tests, plus seven multiplayer session/reconnect contract tests using synthetic sessionStorage/localStorage and static assertions for poll guards, invalid-session cleanup and WebSocket fallback.
- Added build output `dist/amq_learning_tool_v82_69.html`.

## Test totals
- Full runner: 11 commands passed, 0 failed.
- Nine Node suites: 157 assertions passed, 0 failed.
- Integrity verifier: 103 checks passed, 0 failed.

## Acceptance
- User acceptance confirmed on 2026-10-18. This records the user's sign-off for the V82.69 checkpoint; it does not convert unexecuted environment-dependent tests into passes.
- The generated HTML remains 8,786,930 bytes and SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`.
- Candidate, EMQ, history, handoff, answer-flow, storage repository, full-backup validation and multiplayer contract tests are included in the full runner.
- One constrained Chromium UI smoke run on the byte-identical output passed 19 assertions; a later rerun failed with Playwright driver `EPIPE`. The failed rerun is recorded and is not counted as a pass. The successful run remains evidence for the same HTML bytes, but current browser acceptance is still PARTIAL.
- Direct `file://` navigation failed with `ERR_BLOCKED_BY_ADMINISTRATOR`; real-origin persistence, IndexedDB, real audio/network, Firefox and multiplayer multi-client reconnect remain untested.

## GitHub publication
V82.69 branch `v82.69-architecture-storage-multiplayer-01` was created. Status/architecture/test reports, module map, checksum and publication-limit note were read back successfully. The candidate policy module was uploaded and its Git blob SHA matches the local exact blob (`60a1d1944a2ec8ba4e52644dc4af97fc40259ae8`). The storage module draft was removed after its blob did not match; the complete 91-fragment source tree, new test source files and binary ZIP remain unpublished. This branch is not a reproducible remote release. Package SHA-256 is recorded in `reports/V82_69_ARCHITECTURE_STORAGE_MULTIPLAYER_01_SHA256.txt` and the external `.zip.sha256` sidecar.

## Next
1. Close the GitHub publication gap by publishing the exact source fragments, test files, and reproducible build/package workflow, then verify remote readback and blob hashes.
2. Run real-origin acceptance in a permitted browser environment for persistence, IndexedDB, audio recovery, and multiplayer multi-client reconnect.
3. Keep V82.65 immutable and use a new unique checkpoint name for any code changes; do not expand scope without evidence.

## V82.69 完整模組化進度清單（文件盤點）
- 新增 `reports/MODULARIZATION_PROGRESS_CHECKLIST.md` 與 `.csv`，列出 41 個 script/data 片段、50 個 CSS 片段與 2 個已抽出來源模組，共 93 個逐檔追蹤項目。
- 清楚區分「物理切片」與「語意模組化」：目前只有 `candidate_pool_policy.js`、`storage_repository.htmlpart` 兩個來源模組；其他程式片段尚未全部完成責任拆分。
- 本次只新增工程盤點文件，未修改產品 HTML、任何 JS/CSS 片段或模組原始碼。
- 完整清單是初步責任分類；目前函式與依賴盤點仍以 regex inventory 為主，尚不能視為完整 AST 呼叫圖。

## V82.69 modularization dependency inventory — AST pass 01
- Added parser-backed inventory tooling: `tools/ast_dependency_inventory.cjs`, included in `tools/run_all_checks.py`.
- Parsed all 41 script/data fragments: 39 executable JS fragments parsed with zero syntax diagnostics; `script_030` (JSON AniList ID map) and `script_037` (compressed EMQ payload) are explicitly treated as data blocks.
- AST inventory records 809 named function/function-valued definitions and 2,126 direct identifier-call edge records across the fragments. This is a conservative static lead list, not a complete lexical/runtime call graph.
- `script_001` is 5,078,176 bytes; its `DB` initializer is 4,975,240 bytes with 9,516 anime rows and 38,821 song rows. The remaining 102,936 bytes contain executable initialization and status/history functions, so the whole fragment must not be treated as a pure data module.
- `script_004` is 107,042 bytes with 70 named function/function-valued definitions inside its application IIFE. First-pass direct-call scan found 12 unique cross-fragment matches, 9 ambiguous-name call sites and 54 external/global/unresolved call sites.
- Added `reports/AST_DEPENDENCY_MAP.md` and the associated CSV inventories. Updated the modularization checklist with parser evidence and refreshed file byte counts/SHA-256 values from the actual current files.
- No production source fragments, modules, manifest entries, or product HTML were modified. V82.65 HTML baseline remains immutable.

## AST-PASS-01 verification result
- `python tools/run_all_checks.py`: **12 commands passed, 0 failed** (includes all existing unit suites, AST parser inventory, standalone build, and integrity/deterministic rebuild).
- Unit/contracts: **157 assertions passed, 0 failed**.
- Integrity verifier: **103 passed, 0 failed**; two independent builds match each other and immutable V82.65 byte-for-byte.
- Parser inventory: 41 fragments scanned, 39 executable JS parsed without syntax diagnostics, 2 data-only blocks classified separately; no product source changes.
- Real-origin persistence, IndexedDB, live audio/network and multi-client multiplayer remain untested as documented in the accepted V82.69 checkpoint.

## V82.69 quiz suggestion text module — QUIZ-SUGGESTION-TEXT-01
- Extracted the exact existing symbol-normalization, Unicode source-offset mapping and highlight-range helper block from `src/scripts/script_004.htmlpart` into `src/modules/quiz_suggestion_text.js`, injected at the original execution position through the build manifest. No runtime script tag was added.
- Updated `reports/FRAGMENT_MANIFEST.json` and the modularization checklist; tracked file count is now 41 script/data fragments + 50 CSS fragments + 3 source modules = 94 checklist entries.
- Added `tests/unit/quiz_suggestion_helpers_contract.test.cjs`: **16 assertions passed, 0 failed** against the extracted production-source helpers and the existing production comparator.
- `tools/verify.py`: **105 passed, 0 failed**; two independent builds remain byte-identical to immutable V82.65 HTML (8,786,930 bytes; SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`).
- The full runner now has 13 commands. Current unit/contract assertions total **173 passed, 0 failed**.
- Remaining scope: `buildSuggestions()` DOM/UI, events, bounded top-25 selection, playback and answer settlement remain in `script_004`; this extraction does not claim the entire quiz UI is modularized.


## V82.69 quiz suggestion UI integration — QUIZ-SUGGESTION-INTEGRATION-01
- Added `tests/browser/quiz_suggestions_integration.py` and integrated it into `tools/run_all_checks.py`. The harness uses Chromium, in-memory storage and deterministic suggestion fixtures; production `buildSuggestions()`, helper functions, DOM renderer and event wiring remain intact.
- Browser integration: **18 assertions passed**. Full runner: **14 commands passed, 0 failed**; unit/contract suites: **173 passed, 0 failed**; `tools/verify.py`: **105 passed, 0 failed**. Two independent builds remain byte-identical to immutable V82.65 (8,786,930 bytes; SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`).
- Found an existing click-selection accessibility-state conflict: `script_007` capture-phase handler dispatches `input` after clearing the suggestion list, then clears the rebuilt list without resetting `aria-expanded`; result is empty/closed list with `aria-expanded=true`. This is reported as a known issue, not counted as a passing behavior.
- Controller extraction is deferred until event ownership across `script_004`, `script_007`, and `script_008` is reconciled. Full-database enumeration, real-origin persistence, IndexedDB, audio, Firefox and multiplayer remain untested.


## V82.70 quiz suggestion ARIA fix — 2026-10-18
- Fixed the click-selection state mismatch in `script_007.htmlpart`: after dispatching the legacy `input` event and clearing the rebuilt list, set `#quizAnswer[aria-expanded]` to `false`. Existing input event, focus, selected text and caret behavior remain.
- Browser test now asserts the final ARIA state rather than logging it as a known issue.
- New standalone HTML: `dist/amq_learning_tool_v82_70.html`, 8,786,974 bytes, SHA-256 `59704427cb924f2fe9f5526417152b7d743ac29f5cb6dc70c886885e6ae7dca6`.
- Immutable V82.65 baseline remains unchanged at 8,786,930 bytes, SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`. Build/verify now independently validate immutable baseline and current release fingerprint.
- Validation: full runner 14/14 commands passed; browser integration 19 assertions passed; unit/contract suites 173 passed; integrity verifier 106/106; two deterministic builds match.
- Limits: real-origin persistence, IndexedDB, audio/network, Firefox, multiplayer multi-client and full answer submission remain untested. Controller extraction remains deferred until event ownership across scripts 004/007/008 is mapped.


## V82.71 suggestion event ownership audit — 2026-10-18
- Added `reports/V82_71_SUGGESTION_EVENT_OWNERSHIP_AUDIT_01.md` documenting manifest registration order and effective input/click/keyboard/submit ownership across `script_004`, `script_007`, and `script_008`.
- Expanded `tests/browser/quiz_suggestions_integration.py` with assertions that click selection dispatches exactly one bubbling `input` event, restores input focus, places the caret at the end, leaves the list closed with `aria-expanded=false`, and does not invoke the answer-submit bridge or answer-settlement event.
- Targeted Chromium integration: **22 assertions passed, 0 failed**. Full runner: **14 commands passed, 0 failed**; unit/contract: **173 passed, 0 failed**; integrity verifier: **106 passed, 0 failed**; two independent builds match the V82.70 fingerprint.
- No production fragments or manifest release fingerprints changed. V82.70 standalone HTML remains 8,786,974 bytes / SHA-256 `59704427cb924f2fe9f5526417152b7d743ac29f5cb6dc70c886885e6ae7dca6`; immutable V82.65 remains unchanged.
- Consolidation/removal of legacy listeners is deferred; current evidence is sufficient to map ownership but not to safely remove the click handler without first introducing a shared, tested selection contract.


## V82.72 shared quiz suggestion selection — 2026-10-18
- Added a shared `selectQuizSuggestionV8272(value, source)` contract in `script_004`; `script_007` click selection and `script_008` Enter-to-select now call it. It dispatches one bubbling `input` event, lets existing observers update the mirror, closes the list/ARIA, restores focus/caret and refuses selection during IME composition. Answer submission remains a separate unchanged branch.
- Browser regression tests cover click/keyboard parity, exactly-once input event, mirror, list closure/ARIA, focus/caret, no submission/settlement, and IME refusal. Browser: 29 behavioral assertions passed, 0 failed.
- Full runner: 14 commands passed, 0 failed; unit/contracts 173 passed; integrity verifier 106 passed; two builds deterministic.
- Current output: `dist/amq_learning_tool_v82_72.html`, 8,787,018 bytes, SHA-256 `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`. V82.70 is retained; V82.65 baseline remains immutable at its original fingerprint.
- Environment limits remain: no real-origin persistence, IndexedDB, external audio/network, Firefox, multiplayer multi-client or full real-answer submission acceptance. GitHub remains a partial publication until exact source/build files are remotely complete and readback-verified.


## V82.74 DB initializer extraction — 2026-10-18
- Extracted only the 4,975,240-byte `let DB={...};` initializer from `src/scripts/script_001.htmlpart` into `src/modules/anime_song_database.htmlpart`. The module is inserted at the original script position; the following `let anime=DB.anime,songs=DB.songs...` consumers remain after it. No JSON reserialization, key reordering, runtime script tag or product behavior change.
- Added `tests/unit/anime_song_database_extraction_contract.test.cjs`; it reconstructs the original 5,078,176-byte fragment and checks its original SHA-256, 9,516 anime rows, 38,821 song rows, row shapes and consumer order.
- This is an engineering-only source extraction. V82.72 remains the current product output and its fingerprint must remain `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`; V82.65 baseline remains immutable.
- Verification completed: full runner 15 commands passed, 0 failed; unit/contracts 192 assertions passed; browser suggestion integration 29 assertions passed; integrity verifier 108 checks passed; two independent builds match the unchanged V82.72 SHA-256. Package CRC and sidecar SHA-256 verification passed (207 unique entries). Real-origin acceptance remains blocked in the current browser environment; complete GitHub source publication remains outstanding.

- V82.74 report-only GitHub update verified: commit `4493b99beaf7193f052eb16cff051fbc140b896b`; remote report blob SHA `6ccb9b9c035989e26194a0e2fd959a5a30d0d173`. Full source release is still incomplete.
