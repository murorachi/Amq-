# Baseline lock

## Direct V82.65 checkpoint package: recovered and verified

- Package: `AMQ_V82_65_候選題池與篩選資料流整頓檢查點.zip`
- Bytes: `124658780`
- SHA-256: `db7918affcfbb6a15b0dc3265877623d9646532c7597bf2acaa85060f5a701b5`
- External `.sha256` sidecar: exact filename/digest match.
- ZIP CRC: PASS; 291 entries / 291 unique paths.
- Internal `SHA256SUMS.txt`: 290/290 entries verified, no missing paths or mismatches.
- Recovery copy: `/mnt/data/v82_65_baseline_recovery/AMQ_V82_65_候選題池與篩選資料流整頓檢查點.zip` (kept separate and untouched).
- Verification report: `reports/BASELINE_PACKAGE_VERIFICATION_06.md`.

## Locked current V82.65 product assets

| Asset | Bytes | SHA-256 |
|---|---:|---|
| `amq_learning_tool_v82_65_candidate_pool_cleanup.html` | 8,786,930 | `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33` |
| `anisong_multiplayer_room_server_v82_65.py` | 88,403 | `41e79fbabcbc037aef9d2b27076450217673935ede629c16caa956d737ff1736` |
| `anisong_multiplayer_catalog_server.json` | 36,540,011 | `2a045731b9a478e68e88f1965f010f0d7512990344d1d194ef44262f11c5c652` |
| `anisong_multiplayer_unavailable_audio_v82_59.json` | 40 | `a6c6539e68f67e30ef4c0976b04280234352f1b0d61e907138af39050350023a` |

The source archive's `VERSION.json` labels V82.65 as a PARTIAL candidate-pool/filtering checkpoint, not a completed full engineering release. V82.64 Release ZIP remains the direct historical source from which V82.65 was derived.

## Build baseline used by the source split

- Standalone HTML: `baseline/amq_learning_tool_v82_65_candidate_pool_cleanup.html`
- Bytes: 8,786,930
- SHA-256: `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`
- `python tools/verify.py` reconstructs the HTML twice and verifies byte identity to this baseline.

Do not overwrite the original package, the recovered copy, or the locked HTML baseline. Every checkpoint uses a unique artifact name.

## Engineering checkpoint overlay — V82.66 checkpoint 07

The immutable V82.65 HTML fingerprint above remains the build target. Checkpoint V82.66 ANSWER-FLOW-AND-RELIABILITY-07 adds exact-source tests, a one-command local verification runner, and engineering reports only; it does not change the production HTML/runtime. Test results are recorded in reports/ANSWER_FLOW_AND_RELIABILITY_07_TEST_PLAN.md. Product acceptance remains PARTIAL until browser, persistence, audio, and multiplayer checks run in a permitted test environment.


## Engineering checkpoint overlay — V82.67 checkpoint 08

The user confirmed the V82.66 product baseline is satisfactory. Checkpoint `V82.67 BROWSER-UI-SMOKE-08` adds a constrained Chromium UI smoke test and report only. Local and GitHub blob SHA for `tests/unit/candidate_pool_integration.test.cjs` is `c7313fe743157b5c6cde86e252983049be87ff5a`. The UI smoke uses page.set_content() with test-only in-memory storage because the environment blocks file:// and localhost navigation. It does not validate real browser persistence, IndexedDB, real audio, Firefox, or multiplayer. Production HTML remains byte-identical to the immutable V82.65 baseline.


## Engineering checkpoint overlay — V82.68 CANDIDATE-POLICY-MODULE-01

The immutable V82.65 HTML baseline remains 8,786,930 bytes / SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`. V82.68 separates the pure candidate-policy source into `src/modules/candidate_pool_policy.js`, injected at the original position inside the existing classic script. It adds no runtime script tag or external loading and rebuilds byte-identically to baseline. Latest automated run: 8/8 commands passed, 135 Node tests passed, integrity verifier 101/101. Latest constrained browser smoke rerun timed out with Playwright driver EPIPE and is not considered passed; earlier V82.67 smoke evidence remains historical only.


## Engineering checkpoint overlay — V82.69 ARCHITECTURE-STORAGE-MULTIPLAYER-01

The immutable product HTML remains V82.65: 8,786,930 bytes, SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`. V82.69 extracts the existing storage repository script block into `src/modules/storage_repository.htmlpart` and injects its exact bytes at the original position in the standalone document. Candidate policy remains a source module. No product data format or storage migration changed. Build output is named `dist/amq_learning_tool_v82_69.html`. Direct file-origin acceptance is still blocked by the environment. User acceptance of checkpoint V82.69 was explicitly confirmed on 2026-10-18. This is a product checkpoint sign-off, separate from the still-partial environment-dependent browser acceptance and incomplete GitHub source publication.

## V82.69 modularization inventory overlay

`reports/MODULARIZATION_PROGRESS_CHECKLIST.md` and `.csv` enumerate the 41 script/data fragments, 50 CSS fragments, and two extracted source modules present at the V82.69 checkpoint. This is a progress inventory only; it does not change the immutable V82.65 baseline or claim semantic modularization is complete.

## V82.69 AST dependency inventory overlay — AST-PASS-01

The product baseline remains immutable V82.65. This engineering pass adds a TypeScript-parser-backed inventory tool and generated reports only. The 41 script/data fragments were scanned: 39 executable JavaScript fragments parsed without syntax diagnostics; two non-JavaScript data blocks (AniList JSON map and compressed EMQ payload) were excluded from JS parsing. The inventory reports 809 named function/function-valued definitions and 2,126 direct identifier-call edge records, with limitations documented in `reports/AST_DEPENDENCY_MAP.md`. `script_001` is a mixed data/runtime fragment, not a pure data file; `script_004` remains a mixed core application IIFE. No product source fragment or generated HTML was modified.

## V82.69 quiz suggestion helper extraction overlay — QUIZ-SUGGESTION-TEXT-01

`src/modules/quiz_suggestion_text.js` contains the exact existing helper source for uncommon-symbol normalization, normalized-to-original UTF-16 source-offset mapping, and highlight range merging. The module is injected at its original position inside `script_004` with no new runtime script tag. A production-source contract test covers 16 normalization, offset, highlight and comparator assertions. `tools/verify.py` reports 105/105 checks passing and reconstructs the immutable V82.65 standalone HTML byte-identically. This is a bounded helper extraction, not completion of the full quiz UI modularization.


## V82.69 quiz suggestion UI integration overlay — QUIZ-SUGGESTION-INTEGRATION-01

Engineering-only test/documentation update. Added a Chromium integration test for the production suggestion renderer and input wiring using deterministic test suggestions; no production runtime source changed. The test passes 18 assertions and the full runner passes 14/14 commands. It identified a known `aria-expanded` mismatch in the legacy capture-phase click handler in `src/scripts/script_007.htmlpart`: after click selection, the list is empty and closed while the input still reports expanded. Do not extract the UI controller until the overlapping handlers in `script_004`, `script_007`, and `script_008` have a clear single-owner contract. The generated HTML remains byte-identical to immutable V82.65.


## Current release after immutable V82.65 baseline
- V82.65 remains the immutable source baseline: `baseline/amq_learning_tool_v82_65_candidate_pool_cleanup.html`, 8,786,930 bytes, SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`.
- V82.70 `QUIZ_SUGGESTION_ARIA_FIX_01` is a distinct output release, not a new baseline: `dist/amq_learning_tool_v82_70.html`, 8,786,974 bytes, SHA-256 `59704427cb924f2fe9f5526417152b7d743ac29f5cb6dc70c886885e6ae7dca6`. Its expected fingerprint is recorded under `release` in `reports/FRAGMENT_MANIFEST.json`.
- The deterministic builder validates the expected release output while `tools/verify.py` separately confirms the immutable baseline file fingerprint.


## Engineering checkpoint overlay — V82.71 SUGGESTION-EVENT-OWNERSHIP-AUDIT-01

V82.71 is an engineering/test-only checkpoint following V82.70. It documents event registration and ownership across `script_004`, `script_007`, and `script_008`, and expands the production-source Chromium regression test. The standalone product output remains V82.70 (8,786,974 bytes, SHA-256 `59704427cb924f2fe9f5526417152b7d743ac29f5cb6dc70c886885e6ae7dca6`); the immutable V82.65 baseline is unchanged. No production source fragment or manifest fingerprint is changed by this checkpoint.


## Follow-on product output V82.72 (2026-10-18)
- V82.65 remains the immutable baseline: 8,786,930 bytes, SHA-256 `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`.
- V82.70 remains retained at 8,786,974 bytes, SHA-256 `59704427cb924f2fe9f5526417152b7d743ac29f5cb6dc70c886885e6ae7dca6`.
- New V82.72 output: `dist/amq_learning_tool_v82_72.html`, 8,787,018 bytes, SHA-256 `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`. It changes only suggestion selection ownership across scripts 004/007/008 plus matching build metadata/tests. Do not replace the immutable baseline with this release.


## V82.73 engineering-only acceptance attempt (2026-10-18)
- No baseline or product change. V82.65 immutable fingerprint remains 8,786,930 bytes / `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`.
- V82.72 remains the latest product output: 8,787,018 bytes / `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`.
- Local-origin acceptance attempt was blocked by Chromium `net::ERR_BLOCKED_BY_ADMINISTRATOR` before page navigation; no storage behavior was tested. Details in `reports/V82_73_LOCAL_ORIGIN_ACCEPTANCE_BLOCKED_01_REPORT.md`.


## V82.74 source-only DB initializer extraction
The DB initializer (4,975,240 bytes) has been moved byte-for-byte to `src/modules/anime_song_database.htmlpart` and reinserted at its original execution point by the existing marker-based builder. The remaining runtime code in `script_001` is unchanged and stays in place. The intended product output is byte-identical V82.72; this source-only refactor does not change the immutable V82.65 baseline or the current release fingerprint. See `reports/V82_74_DB_INITIALIZER_EXTRACTION_01_REPORT.md` for executed verification.


## V82.75 QUIZ SUGGESTION RENDERER EXTRACTION 01

- Engineering source checkpoint only; immutable product baseline remains V82.65 and current product output remains V82.72.
- `renderQuizSuggestionLabelV824()` and `buildSuggestions()` are stored in `src/modules/quiz_suggestion_renderer.js` and reinserted at the original classic-script position.
- Expected output: 8,787,018 bytes / SHA-256 `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`. Any change to this fingerprint is a regression unless separately authorized.


## V82.76 SCRIPT004 BOUNDARY AUDIT 01

Engineering-only static analysis checkpoint. Immutable V82.65 baseline remains `abd202a6f96cc08e0969ad05ab8574cc71001733d655bcb5cff6b1a1a5b33a33`; current product output remains V82.72 at `fb075ed4e68eca454051ecd22cc10d3e7a5def193bf2852bf91547d5465da0d8`. The audit fingerprints `src/scripts/script_004.htmlpart` at 98,849 bytes / `23dacccdc25538416c4ddba91f4e044df7c4491924d1099d8cdf0a60fb4f4bdc`. No product source or module insertion position changed.
