# Core script_004 dependency boundary audit (V82.76)

- Source: `src/scripts/script_004.htmlpart`
- Source bytes: 98849
- Source SHA-256: 23dacccdc25538416c4ddba91f4e044df7c4491924d1099d8cdf0a60fb4f4bdc
- Parser: TypeScript parser; syntax diagnostics: 0
- Scope: static evidence only. This report is not a complete lexical resolver or runtime call graph and makes no source changes.
- The outer IIFE closure contains shared state and helpers. Moving code across this boundary can alter initialization order and closure access even when the HTML output can be rebuilt.

## Shared closure state candidates

The table lists direct declarations in the outer IIFE that are referenced from multiple function owners or assigned at least once. Reads/writes are heuristic identifier-reference counts, not a fully resolved data-flow graph.

| Symbol | Kind | Decl. line | Reads | Writes | Function owners |
|---|---|---:|---:|---:|---:|
| `quizSong` | variable | 29 | 103 | 6 | 28 |
| `quizSettings` | variable | 40 | 119 | 4 | 28 |
| `quizFinished` | variable | 29 | 13 | 9 | 17 |
| `quizActive` | variable | 29 | 9 | 5 | 14 |
| `quizAudioStarted` | variable | 29 | 6 | 6 | 10 |
| `quizStartedAt` | variable | 29 | 8 | 7 | 9 |
| `readQuizSettingsUI` | function | 41 | 9 | 0 | 9 |
| `activeFocusSongIdsV72` | variable | 40 | 8 | 5 | 8 |
| `lastQuestionId` | variable | 29 | 5 | 5 | 8 |
| `nextQuiz` | function | 52 | 11 | 1 | 8 |
| `quizRoundSeen` | variable | 40 | 10 | 0 | 8 |
| `quizRound` | variable | 40 | 9 | 7 | 7 |
| `quizAutoNextPausedV30` | variable | 188 | 6 | 4 | 7 |
| `quizAutoNextRemainingMsV30` | variable | 188 | 4 | 4 | 7 |
| `activeFocusModeV72` | variable | 40 | 7 | 2 | 7 |
| `clearQuizAutoNextV30` | function | 240 | 9 | 0 | 7 |
| `clearQuizPlaybackV30` | function | 260 | 13 | 0 | 7 |
| `quizRootV30` | variable | 178 | 11 | 0 | 7 |
| `updateQuizPlaybackV30` | function | 261 | 9 | 0 | 7 |
| `quizAnswerStopAt` | variable | 40 | 5 | 5 | 6 |
| `currentQuestionTarget` | variable | 29 | 7 | 4 | 6 |
| `quizAutoNextDeadlineV30` | variable | 188 | 7 | 4 | 6 |
| `quizRoundTarget` | variable | 40 | 1 | 6 | 5 |
| `quizClipDeadlineV30` | variable | 187 | 8 | 3 | 5 |
| `quizPracticeMetaV8239` | variable | 290 | 4 | 1 | 5 |
| `countdownV30` | variable | 227 | 14 | 0 | 5 |
| `updateQuizCounts` | function | 49 | 5 | 0 | 5 |
| `quizPauseClockStartedAtV82` | variable | 262 | 5 | 3 | 4 |
| `quizPausedElapsedV82` | variable | 262 | 3 | 3 | 4 |
| `quizClipTimer` | variable | 40 | 8 | 1 | 4 |
| `submitQuiz` | function | 89 | 7 | 1 | 4 |
| `classifyQuiz` | function | 65 | 4 | 0 | 4 |
| `clearQuizAutoNextTimersV30` | function | 232 | 4 | 0 | 4 |
| `getQuizPracticeMetaV8239` | function | 293 | 4 | 0 | 4 |
| `loadQuizSettings` | function | 42 | 4 | 0 | 4 |

Full list: `reports/CORE_SCRIPT_004_SHARED_STATE.csv`.

## DOM / browser API call sites

| API | Calls | Function owners | First line |
|---|---:|---:|---:|
| `document.getElementById` | 190 | 37 | 35 |
| `document.createElement` | 18 | 7 | 5 |
| `document.body.classList.contains` | 15 | 14 | 52 |
| `localStorage.setItem` | 14 | 9 | 41 |
| `performance.now` | 12 | 10 | 72 |
| `localStorage.getItem` | 11 | 6 | 42 |
| `document.addEventListener` | 9 | 2 | 160 |
| `console.error` | 8 | 6 | 36 |
| `window.__aniEmqAPI?.isSong` | 8 | 7 | 79 |
| `window.__aniEmqAPI?.getWorkSummary` | 7 | 6 | 34 |
| `document.querySelectorAll` | 6 | 2 | 41 |
| `document.dispatchEvent` | 5 | 5 | 52 |
| `window.__aniChineseTitleAPIv8237?.getAliases` | 5 | 3 | 108 |
| `window.__aniCandidatePoolPolicyV8265.settingNumber` | 4 | 1 | 41 |
| `document.body.classList.remove` | 3 | 3 | 35 |
| `window.__aniSelectedCustomListIdsV825` | 3 | 1 | 41 |
| `window.__aniEmqAPI?.getAliases` | 3 | 3 | 107 |
| `document.body.appendChild` | 3 | 3 | 197 |
| `window.matchMedia` | 3 | 3 | 286 |
| `document.querySelector` | 2 | 2 | 3 |
| `window.__aniNavigateApp` | 2 | 2 | 38 |
| `window.__aniCandidatePoolPolicyV8265.repeatAllowed` | 2 | 1 | 47 |
| `window.__aniEmqAPI?.getRows` | 2 | 2 | 49 |
| `document.getElementById('quizSuggestions').classList.remove` | 2 | 2 | 51 |
| `window.__aniQuizPauseClockV82?.reset` | 2 | 2 | 52 |
| `document.getElementById('quizNext')?.removeAttribute` | 2 | 2 | 62 |
| `window.__aniHistoryAPIv51?.record` | 2 | 2 | 81 |
| `window.__aniQuizPlanV1?.clearFocus` | 2 | 2 | 160 |
| `window.__aniHistoryAPIv51?.beginRound` | 2 | 2 | 162 |
| `localStorage.removeItem` | 2 | 2 | 172 |

Full list: `reports/CORE_SCRIPT_004_API_TOUCHPOINTS.csv`. API coverage is syntactic and only includes recognized property-call prefixes; computed properties and indirect wrappers may be missed.

## Global exports

- L37: `window.__aniEnterQuizV82` (<anonymous@2>)
- L37: `window.__aniDeactivateQuizV82` (<anonymous@2>)
- L50: `window.__aniEmqToggleChangedV1` (<anonymous@2>)
- L53: `window.mediaFiles` (playQuizAudio)
- L53: `window.mediaFiles` (playQuizAudio)
- L134: `window.__aniQuizHandleAudioFailureV857` (<anonymous@2>)
- L137: `window.__aniQuizSubmitV47` (<anonymous@2>)
- L138: `window.__aniQuizClassifyV47` (<anonymous@2>)
- L139: `window.__aniQuizNextV47` (<anonymous@2>)
- L140: `window.__aniQuizStopStateV82` (<anonymous@2>)
- L164: `window.mediaFiles` (<anonymous@2>)
- L259: `window.__aniQuizAutoNextV30` (<anonymous@2>)
- L264: `window.__aniQuizPauseClockV82` (<anonymous@2>)
- L307: `window.__aniSongPracticeMetaAPIv8239` (<anonymous@2>)
- L429: `window.__aniQuizPlanV1` (<anonymous@2>)

## Listener ownership candidates

- L160 (<anonymous@2>): `document.addEventListener('click',e=>{if(e.target.closest?.('#blindNextBtn')){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();window.__aniNavigateApp?.('quiz');return}if(e.target.closest?.('#quizExit')){e.preventDefault();e.stopPropagation(`
- L161 (<anonymous@2>): `document.addEventListener('ani-app-navigation',e=>{if(e.detail?.view!=='quiz')window.__aniQuizPlanV1?.clearFocus()})`
- L162 (<anonymous@2>): `document.addEventListener('click',e=>{const button=e.target?.closest?.('#quizManualPlayV8262');if(!button)return;if(document.body.classList.contains('quiz-round-paused')){const status=document.getElementById('quizStatus');if(status)status.textContent='本輪已暫停，請先`
- L162 (<anonymous@2>): `document.getElementById('quizAnswer').addEventListener('input',buildSuggestions)`
- L162 (<anonymous@2>): `document.addEventListener('click',e=>{if(!e.target.closest('.quizSuggest'))document.getElementById('quizSuggestions').classList.remove('open')})`
- L167 (<anonymous@2>): `document.getElementById('themeToggle')?.addEventListener('click',()=>applyTheme(!document.body.classList.contains('dark-theme')))`
- L167 (<anonymous@2>): `document.getElementById('quizThemeToggle')?.addEventListener('click',()=>applyTheme(!document.body.classList.contains('dark-theme')))`
- L205 (<anonymous@2>): `document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!settingsOverlayV30.classList.contains('hidden')){settingsOverlayV30.classList.add('hidden');setTimeout(()=>quizSettingsToggleV30?.focus({preventScroll:true}),0)}})`
- L295 (<anonymous@2>): `document.addEventListener('ani-quiz-new-question',()=>{quizQuestionTokenV8239++})`
- L303 (<anonymous@2>): `document.addEventListener('ani-quiz-answer-submitted',event=>{
 const state=window.__aniQuizStateV45||{},id=String(state.quizSong?.[1]??'');if(!id)return;
 const old=getQuizPracticeMetaV8239(id)||{};quizPracticeMetaV8239[id]={...old,lastAnswer:String(event.det`
- L348 (createQuizFloatingDetailV8239): `document.addEventListener('keydown',event=>{if(event.key==='Escape'&&quizFloatingDetailV8239&&!quizFloatingDetailV8239.panel.hidden)quizFloatingDetailV8239.panel.hidden=true})`
- L426 (<anonymous@2>): `document.getElementById(id)?.addEventListener('change',()=>{readQuizSettingsUI();applyQuizDisplaySettingsV30()})`
- L427 (<anonymous@2>): `document.addEventListener('ani-familiarity-updated-v51',()=>{try{updateQuizCounts()}catch(e){}})`

## Timer / animation scheduling candidates

- L52 (nextQuiz): `clearTimeout(quizClipTimer)`
- L58 (skipUnplayedQuizQuestionV80): `clearTimeout(quizClipTimer)`
- L70 (classifyQuiz): `clearTimeout(quizClipTimer)`
- L134 (<anonymous@134>): `setTimeout(()=>{if(quizActive&&quizSong&&String(quizSong[1])===id&&quizFinished&&!document.body.classList.contains('quiz-round-paused'))nextQuiz()},350)`
- L142 (<anonymous@140>): `clearTimeout(quizClipTimer)`
- L162 (<anonymous@162>): `setTimeout(()=>{if(document.activeElement===quizAnswerInput)buildSuggestions()},0)`
- L170 (<anonymous@170>): `setTimeout(()=>document.getElementById('quizSettingsCloseV30')?.focus({preventScroll:true}),0)`
- L203 (<anonymous@203>): `setTimeout(()=>quizSettingsToggleV30?.focus({preventScroll:true}),0)`
- L204 (<anonymous@204>): `setTimeout(()=>quizSettingsToggleV30?.focus({preventScroll:true}),0)`
- L205 (<anonymous@205>): `setTimeout(()=>quizSettingsToggleV30?.focus({preventScroll:true}),0)`
- L232 (clearQuizAutoNextTimersV30): `clearTimeout(quizAutoNextTimerV30)`
- L232 (clearQuizAutoNextTimersV30): `clearInterval(quizAutoNextTickV30)`
- L244 (startQuizAutoNextV30): `setInterval(renderQuizAutoNextV30,150)`
- L245 (startQuizAutoNextV30): `setTimeout(()=>{
  clearQuizAutoNextTimersV30();quizAutoNextDeadlineV30=0;quizAutoNextRemainingMsV30=null;quizAutoNextPausedV30=false;
  if(countdownV30){countdownV30.classList.add('hidden');countdownV30.textContent=''}
  if(!document.body.classList.contains('`
- L260 (clearQuizPlaybackV30): `clearInterval(quizPlaybackTickerV30)`
- L260 (clearQuizPlaybackV30): `clearTimeout(quizStopTimerV30)`
- L336 (<anonymous@336>): `setTimeout(hide,7000)`
- L411 (startQuizPlaybackTickerV30): `setInterval(()=>{
   if(document.body.classList.contains('quiz-round-paused'))return;
   /* V82.1: freeze the clip timer while the pause control is active. */
   if(!quizActive||!quizSong||quizFinished){clearQuizPlaybackV30();return}
   const left=Math.max(0,(`

## Extracted-module constraints

- Existing suggestion text, controller and renderer blocks remain inserted at their original classic-script positions.
- The outer IIFE shares local bindings with quiz settings, candidate-pool assembly, playback state, answer submission, history and event listeners. This audit does not justify extracting those regions yet.
- Next safe step: create a per-responsibility call/DOM/state contract for one bounded region, then add production-source regression assertions before moving it.

## Known limitations

1. Name matching does not resolve shadowing or lexical scopes fully; same-named locals can affect counts.
2. Read/write classification handles simple assignment and increment/decrement patterns, not destructuring, reflective writes, aliases or mutation through object properties.
3. Listener registration through aliases, delegated frameworks, and listeners in later compatibility scripts is outside this fragment's scope.
4. No real-origin, audio, IndexedDB, or multiplayer acceptance is inferred from static analysis.
