# Next task

Current engineering checkpoint: **V82.76 SCRIPT004-BOUNDARY-AUDIT-01**. Current standalone product remains **V82.72**; immutable baseline remains V82.65.

## Latest completed task
- Added `tools/script004_boundary_audit.cjs` and `tests/unit/script004_boundary_audit_contract.test.cjs`.
- Generated `reports/CORE_SCRIPT_004_BOUNDARY_AUDIT.md`, `CORE_SCRIPT_004_SHARED_STATE.csv`, and `CORE_SCRIPT_004_API_TOUCHPOINTS.csv`.
- Parser diagnostics: 0. Audit contract: 15 assertions. It documents shared closure-state references, DOM/browser API call sites, `window` exports, event listeners and timers without rewriting production code.
- Full runner: 18 commands expected after the new audit contract was integrated; final actual counts and product fingerprint must be taken from `reports/ALL_CHECKS_V82_76_SCRIPT004_BOUNDARY_AUDIT_01.txt`.

## Next highest-value task
1. Add a production-source characterization contract for `getQuizPool()` in `script_004.htmlpart`, including candidate ID/order, blank-title/orphan rejection, policy composition, focus mode, repeat guard, source mode, custom-list scope and empty-pool behavior. Reuse existing candidate-policy and candidate-pool integration fixtures where applicable; do not duplicate entire test suites.
2. Trace the function's direct inputs (`quizSettings`, focus IDs/state, round-seen IDs, `lastQuestionId`, `songs`, `byAnime`, status/tag/list/audio adapters) and exact return-order semantics.
3. Only after the characterization contract passes against the unchanged production source, consider moving the smallest contiguous candidate-pool block to a build-time module at the exact original insertion point. Preserve classic-script scope and runtime order.
4. Keep quiz settings UI binding, playback, answer submission, history and multiplayer separate until their state/event contracts are explicit.

## Open release and acceptance gaps
- The source ZIP intentionally excludes `dist/`; run `python tools/build.py` before browser integration tests that require the generated HTML.
- Chromium localhost navigation previously failed with `ERR_BLOCKED_BY_ADMINISTRATOR`; real-origin localStorage/IndexedDB, live audio/network, Firefox and multiplayer multi-client reconnect remain unverified.
- GitHub branch `v82.69-architecture-storage-multiplayer-01` still lacks a coherent complete source/build/test publication. Report-only uploads do not close this gap.
- Preserve V82.65, V82.70 and V82.72 outputs. Do not overwrite baseline or claim environment-dependent acceptance without evidence.

## Commands
```bash
python tools/build.py
node tools/script004_boundary_audit.cjs
node tests/unit/script004_boundary_audit_contract.test.cjs
python tools/run_all_checks.py
python tools/verify.py
python tools/package_checkpoint.py
```
